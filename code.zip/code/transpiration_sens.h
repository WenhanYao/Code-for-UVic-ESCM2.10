! source file: /public/home/xiaoyujin/app/UVic_ESCM/2.10/source/mtlm/transpiration_sens.h
!===================== include file "transpiration_sens.h" ======================

!     parameter definitions for the option F_transpiration_sensitivity_scaling

!-----------------------------------------------------------------------
!      set parameters for transpiration sensitivity study
!-----------------------------------------------------------------------

! sens_fact scales the strength of CO2 increase relative to preindustrial levels
! that is used to calculate vegetational transpiration response to CO2

      real sens_fact
      common /land_s/ sens_fact

