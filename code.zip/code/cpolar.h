! source file: /public/home/xiaoyujin/app/UVic_ESCM/2.10/source/common/cpolar.h
!====================== include file "cpolar.h" =========================

!     polar transform coefficients used to transform velocities near
!     poles before filtering

      real spsin, spcos
      common /cpolar_r/ spsin(imt), spcos(imt)
