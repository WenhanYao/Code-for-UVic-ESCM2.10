! source file: /public/home/xiaoyujin/app/UVic_ESCM/2.10/source/mtlm/CO2_fertilization_scaling.h
!===================== include file "CO2_fertilization_scaling.h" ======================

!     parameter definitions for the option CO2_fertilization_scaling

!-----------------------------------------------------------------------
!      set parameters for CO2 fertilization sensitivity study
!-----------------------------------------------------------------------

! scaling scales the strength of CO2 increase relative to preindustrial levels
! that is used to calculate all processes in the canopy and leaf routines

      real co2_fert_scal
      common /land_n/ co2_fert_scal

